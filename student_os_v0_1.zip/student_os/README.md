# Student OS — Semester 4

A personal Streamlit dashboard for Trishul's CSE Semester 4 and placement preparation.

## What's included

- **Command Center:** overall roadmap progress, task queue, study-time log and current priorities.
- **Roadmaps:** DSA, Python/OOP, PostgreSQL, FastAPI, Git/GitHub, Cloud/DevOps and semester subjects (DAA, DBMS, OS, Calculus).
- **Daily Planner:** add tasks, due dates, estimated time, completion and actual focused-study logs.
- **AI Tutor:** persistent chat using the OpenAI Responses API, with teaching modes for explanations, debugging, attempt review, quizzes and session planning.
- **Settings & Export:** daily study target, configuration guidance and JSON backup.

The curriculum is a **personal planning scaffold**, not an official GITAM course syllabus. Replace university checkpoints with the faculty handouts and lab manuals when available.

## Run locally (Windows / PowerShell)

```powershell
cd student_os
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .streamlit\secrets.toml.example .streamlit\secrets.toml
notepad .streamlit\secrets.toml
streamlit run app.py
```

Paste your API key into `.streamlit/secrets.toml` only if you want the AI Tutor enabled. The rest of the dashboard works without an API key.

## Run locally (Linux / WSL)

```bash
cd student_os
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
nano .streamlit/secrets.toml
streamlit run app.py
```

## Secrets

The local `.streamlit/secrets.toml` file is ignored by Git. For Streamlit Community Cloud, add these in the app's Secrets settings:

```toml
OPENAI_API_KEY = "your-api-key"
OPENAI_MODEL = "gpt-5.5"
APP_PASSWORD = "a-long-private-password"
DATABASE_URL = "postgresql+psycopg://USER:PASSWORD@HOST:5432/DATABASE"
```

- `OPENAI_API_KEY` enables the AI tutor. API usage is billed separately from a ChatGPT subscription.
- `OPENAI_MODEL` can be changed to a model available to your API account.
- `APP_PASSWORD` adds a simple shared-password gate. This is suitable only as a basic personal-app barrier, not as production multi-user authentication.
- `DATABASE_URL` is optional locally. Without it, the app stores data in `student_os.db` using SQLite.

## Important persistence note

Use hosted PostgreSQL (`DATABASE_URL`) when deploying and depending on progress history. Streamlit Community Cloud does not guarantee persistence for files generated while an app is running, so the local SQLite fallback is intended for local development/testing. Back up progress from **Settings & Export** periodically.

## Deploy to Streamlit Community Cloud

1. Create a private GitHub repository and upload this project (do **not** upload your real `secrets.toml`).
2. Connect the repository to Streamlit Community Cloud and select `app.py` as the entry point.
3. Add the secrets above in the app's Secrets panel.
4. Add a PostgreSQL `DATABASE_URL` before using the hosted app as your main progress tracker.
5. Keep the repository private and set `APP_PASSWORD` because the app contains personal study data and uses your API key.

## First-use checklist

1. Open **Roadmaps → DSA · Python** and begin with arrays + hashing after reviewing complexity analysis.
2. Open **Roadmaps → Python · OOP** and work through the OOP checkpoints using your Vehicle, Person and Dog examples.
3. Open **Roadmaps → PostgreSQL · DBMS** and focus next on joins, grouping and subqueries.
4. Add only 2–4 concrete tasks to the Daily Planner at a time.
5. Log actual focused work and mark milestones complete only after you can demonstrate the skill independently.

## Design decisions / current limits

- Single-user personal MVP. The shared password is not a full authentication system.
- Roadmap progress, tasks, study sessions and tutor chat are stored in the configured database.
- University course checkpoints are generic until official course material is added.
- No calendar sync, notifications, file upload/RAG, multi-user accounts or automatic syllabus import yet.
